# Tenure prototype

Open `index.html` in any modern browser. No install is needed. Keep the `img/` folder next to it.

Live link: https://tenure0.netlify.app

Passports are saved in the browser only. Clearing site data removes them.
